from app.services.citation_matcher import match_citations_to_references


def test_numeric_citation_match():
    citations=[{'style_detected':'numeric_bracket','text':'[1]'}]
    refs=['[1] Smith, J. 2020. A study about citation testing.']
    result=match_citations_to_references(citations,refs)
    assert result[0]['match_status']=='matched'
    assert result[0]['matched_reference_index']==0


def test_unmatched_citation():
    citations=[{'style_detected':'numeric_bracket','text':'[9]'}]
    result=match_citations_to_references(citations,['Smith, J. 2020. Study title'])
    assert result[0]['match_status']=='unmatched'
