from app.services.evidence_search import search_evidence

def test_search_returns_relevant_passage_with_page():
    pages=[{'page':1,'text':'A randomized clinical trial showed that exercise significantly improved sleep quality in adults. Another unrelated sentence describes weather patterns.'}]
    result=search_evidence('exercise improved sleep quality in adults',pages)
    assert result['passages']
    assert result['passages'][0]['page']==1
    assert 'lexical_overlap' in result['passages'][0]['score_type']
    assert 'not proof' in result['note']

def test_empty_claim_returns_no_passages():
    result=search_evidence('',[{'page':1,'text':'some passage'}])
    assert result['passages']==[]
