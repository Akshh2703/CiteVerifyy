from app.services.document_parser import split_references, detect_citations, detect_claims

def test_reference_split():
    body, refs, entries=split_references('A claim supported by research.\n\nReferences\n[1] Smith, J. 2020. Example paper.')
    assert 'A claim supported' in body
    assert '[1] Smith' in refs
    assert entries

def test_citation_detection():
    items=detect_citations('This is supported [1, 2]. Smith (2021) reports https://example.com and doi 10.1234/abcd.')
    kinds={i['style_detected'] for i in items}
    assert 'numeric_bracket' in kinds and 'doi' in kinds and 'url' in kinds

def test_claim_candidate():
    items=detect_claims('This intervention improves performance significantly across the observed population, according to the results.')
    assert items and items[0]['review_required'] is True
