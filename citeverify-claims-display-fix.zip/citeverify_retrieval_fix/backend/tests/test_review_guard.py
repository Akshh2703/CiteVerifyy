import os
import tempfile
from pathlib import Path



def test_report_approval_requires_claims_reviewed(monkeypatch):
    from app.services import review_store
    tempdb=Path(tempfile.gettempdir())/'citeverify-test-review-guard.sqlite3'
    tempdb.unlink(missing_ok=True)
    monkeypatch.setattr(review_store,'DB_PATH',tempdb)
    review_store.create_review('r1','doc1',{'claims':[{'claim_id':'c1','human_approved':False,'human_rejected':False,'human_verdict':None}]})
    try:
        review_store.update_review('r1','reviewer',None,'approve_report',{})
        assert False, 'Expected report approval to be blocked'
    except ValueError as exc:
        assert 'All claims must be reviewed' in str(exc)
    review_store.update_review('r1','reviewer','c1','approve_claim',{'comment':'Checked'})
    result=review_store.update_review('r1','reviewer',None,'approve_report',{})
    assert result['payload']['human_report_approved'] is True
    tempdb.unlink(missing_ok=True)
