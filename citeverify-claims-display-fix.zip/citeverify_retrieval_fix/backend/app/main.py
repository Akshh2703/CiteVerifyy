from __future__ import annotations
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Any
import hashlib
import re
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from app.services.document_parser import extract_document, split_references, detect_citations, detect_claims
from app.services.citation_matcher import match_citations_to_references
from app.services.research_lookup import search_research, discover_open_access
from app.services.claim_citation_mapper import map_claims_to_citations

app=FastAPI(title='CiteVerify API',version='0.2.0',description='Research citation and evidence verification backend')
app.add_middleware(
    CORSMiddleware,
    allow_origins=['http://localhost:5173','http://127.0.0.1:5173','http://localhost:5174','http://127.0.0.1:5174'],
    allow_origin_regex=r'^https?://(localhost|127\.0\.0\.1)(:\d+)?$',
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)
MAX_FILE_BYTES=20*1024*1024
SUPPORTED={'.pdf','.docx','.txt'}

@app.post('/api/chat')
def chat_with_llm(payload: dict[str, Any]):
    """Document-grounded chat using Groq hosted LLM."""
    import os, requests
    api_key=os.getenv('GROQ_API_KEY','').strip()
    if not api_key: raise HTTPException(503,'Set GROQ_API_KEY in backend environment and restart.')
    question=str(payload.get('question','')).strip()
    if not question: raise HTTPException(400,'question is required')
    analysis=payload.get('analysis',{})
    if not isinstance(analysis,dict): raise HTTPException(400,'analysis must be an object')
    pages=analysis.get('pages',[])
    doc_text='\n\n'.join(str(p.get('text','')) for p in pages if isinstance(p,dict))[:18000]
    context={'document':analysis.get('document',{}),'claims':analysis.get('claims',[]),'citations':analysis.get('citations',[]),'references':analysis.get('references',[]),'citation_matches':analysis.get('citation_matches',[])}
    system=('You are CiteVerify, a research citation-checking assistant. Answer using the uploaded document context. Do not invent sources, evidence, DOIs, page numbers, or verification results. Extraction and citation metadata do not prove support. Clearly state that cited-paper full text has not been retrieved unless source passages are explicitly in context. Distinguish document text from inference.\n\nANALYSIS JSON:\n'+str(context)+'\n\nDOCUMENT TEXT:\n'+doc_text)
    messages=[{'role':'system','content':system}]
    history=payload.get('history',[])
    if isinstance(history,list):
        for m in history[-8:]:
            if isinstance(m,dict) and m.get('role') in ('user','assistant') and isinstance(m.get('text'),str): messages.append({'role':m['role'],'content':m['text'][:3000]})
    messages.append({'role':'user','content':question})
    model=os.getenv('GROQ_MODEL','llama-3.3-70b-versatile')
    try:
        r=requests.post('https://api.groq.com/openai/v1/chat/completions',headers={'Authorization':'Bearer '+api_key,'Content-Type':'application/json'},json={'model':model,'messages':messages,'temperature':0.2,'max_tokens':900},timeout=45)
        if r.status_code>=400: raise HTTPException(r.status_code,'LLM provider error: '+r.text[:400])
        return {'answer':r.json()['choices'][0]['message']['content'].strip(),'provider':'Groq','model':model}
    except requests.Timeout as exc: raise HTTPException(504,'LLM request timed out. Try again.') from exc
    except requests.RequestException as exc: raise HTTPException(502,'Could not reach LLM provider.') from exc
    except (KeyError,ValueError,IndexError) as exc: raise HTTPException(502,'Unexpected LLM response.') from exc

@app.get('/api/health')
def health(): return {'status':'ok','service':'CiteVerify API','version':'0.2.0'}

@app.post('/api/analyze-document')
async def analyze_document(file: UploadFile=File(...)):
    filename=file.filename or 'uploaded-file'; suffix=Path(filename).suffix.lower()
    if suffix not in SUPPORTED: raise HTTPException(415,'Supported formats: PDF, DOCX, TXT')
    data=await file.read()
    if not data: raise HTTPException(400,'Uploaded file is empty')
    if len(data)>MAX_FILE_BYTES: raise HTTPException(413,'File exceeds 20 MB limit')
    # Basic content-type/extension mismatch guard, while accepting common browser MIME variations.
    with NamedTemporaryFile(suffix=suffix,delete=False) as tmp:
        tmp.write(data); path=Path(tmp.name)
    try:
        page_data=extract_document(path,suffix)
    except Exception as exc:
        raise HTTPException(422,'Document could not be parsed. It may be corrupt, encrypted, or image-only.') from exc
    finally: path.unlink(missing_ok=True)
    full_text='\n\n'.join(p['text'] for p in page_data if p.get('text'))
    if not full_text.strip(): raise HTTPException(422,'No selectable text found. Scanned PDFs require OCR, which is not enabled yet.')
    body,ref_text,references=split_references(full_text)
    citations=detect_citations(body)
    claims=detect_claims(body)
    citation_matches=match_citations_to_references(citations,references)
    claim_citation_map=map_claims_to_citations(claims,citations)
    return {'document_id':hashlib.sha256(data).hexdigest()[:16],'filename':filename,'file_type':suffix[1:],'pages':page_data,'page_count':len(page_data) if suffix=='.pdf' else None,'text_characters':len(full_text),'claims':claims,'citations':citations,'citation_matches':citation_matches,'claim_citation_map':claim_citation_map,'references':references,'reference_section_detected':bool(ref_text),'processing_notes':['Claim detection is a transparent heuristic and produces candidates only.','Citation pattern detection is style-agnostic but may miss unusual citation formats.','DOCX/TXT pagination is unavailable; page numbers are not inferred.','Scanned PDFs without selectable text are not OCR-processed.','No source retrieval or support verdict is produced at this stage.']}


@app.post('/api/analysis-pipeline')
async def analysis_pipeline(file: UploadFile=File(...)):
    """Run extraction, claim/citation parsing, reference matching, and conservative triage in one request."""
    from app.services.pipeline import build_analysis
    filename=file.filename or 'uploaded-file'
    suffix=Path(filename).suffix.lower()
    if suffix not in SUPPORTED: raise HTTPException(415,'Supported formats: PDF, DOCX, TXT')
    data=await file.read()
    if not data: raise HTTPException(400,'Uploaded file is empty')
    if len(data)>MAX_FILE_BYTES: raise HTTPException(413,'File exceeds 20 MB limit')
    with NamedTemporaryFile(suffix=suffix,delete=False) as tmp:
        tmp.write(data); path=Path(tmp.name)
    try:
        page_data=extract_document(path,suffix)
    except Exception as exc:
        raise HTTPException(422,'Document could not be parsed. It may be corrupt, encrypted, or image-only.') from exc
    finally:
        path.unlink(missing_ok=True)
    if not any(str(p.get('text','')).strip() for p in page_data):
        raise HTTPException(422,'No selectable text found. Scanned PDFs require OCR, which is not enabled yet.')
    doc_id=hashlib.sha256(data).hexdigest()[:16]
    analysis=build_analysis(page_data,filename,doc_id,suffix[1:])
    # Automatically retrieve papers for extracted bibliography entries (best-effort).
    try:
        from app.services.paper_pipeline import retrieve_references
        analysis['paper_retrieval']=retrieve_references(analysis.get('references',[]))
        from app.services.paper_pipeline import assess_claims
        analysis['claim_assessments']=assess_claims(analysis.get('claims',[]),analysis['paper_retrieval'])
    except Exception as exc:
        analysis['paper_retrieval']={'references_processed':0,'items':[],'error':type(exc).__name__,'note':'Paper retrieval could not be completed.'}
    return analysis


@app.post('/api/research-search')
def research_search(payload: dict[str, Any]):
    query=str(payload.get('query','')).strip()
    if not query: raise HTTPException(400,'query is required')
    try: limit=int(payload.get('limit',5))
    except (TypeError,ValueError): limit=5
    return search_research(query,limit)

@app.post('/api/match-citations')
def match_citations(payload: dict[str, Any]):
    citations=payload.get('citations',[])
    references=payload.get('references',[])
    if not isinstance(citations,list) or not isinstance(references,list):
        raise HTTPException(400,'citations and references must be arrays')
    return {'matches':match_citations_to_references(citations,references)}


@app.post('/api/map-claims-citations')
def map_claims_citations(payload: dict[str, Any]):
    claims=payload.get('claims',[])
    citations=payload.get('citations',[])
    if not isinstance(claims,list) or not isinstance(citations,list):
        raise HTTPException(400,'claims and citations must be arrays')
    return {'mapped_claims':map_claims_to_citations(claims,citations)}


@app.post('/api/open-access-discovery')
def open_access_discovery(payload: dict[str, Any]):
    query=str(payload.get('doi_or_query','')).strip()
    if not query: raise HTTPException(400,'doi_or_query is required')
    return discover_open_access(query)

@app.post('/api/evidence-search')
def evidence_search(payload: dict[str, Any]):
    from app.services.evidence_search import search_evidence
    claim=str(payload.get('claim','')).strip()
    pages=payload.get('pages',[])
    if not claim: raise HTTPException(400,'claim is required')
    if not isinstance(pages,list): raise HTTPException(400,'pages must be an array of page/text objects')
    return search_evidence(claim,pages, payload.get('limit',5))

@app.post('/api/reviews')
def create_review_session(payload: dict[str, Any]):
    import uuid
    from app.services.review_store import create_review
    document_id=str(payload.get('document_id','')).strip()
    claims=payload.get('claims',[])
    if not document_id: raise HTTPException(400,'document_id is required')
    if not isinstance(claims,list): raise HTTPException(400,'claims must be an array')
    prepared=[]
    for idx,claim in enumerate(claims,1):
        if not isinstance(claim,dict): continue
        prepared.append({**claim,'claim_id':str(claim.get('claim_id') or f'claim-{idx}'),'verdict':claim.get('verdict','Unverifiable'),'human_verdict':None,'human_approved':False,'human_rejected':False,'review_comments':[]})
    review_id=str(uuid.uuid4())
    return create_review(review_id,document_id,{'claims':prepared,'document':payload.get('document',{})})


@app.get('/api/reviews/{review_id}')
def get_review_session(review_id: str):
    from app.services.review_store import get_review
    review=get_review(review_id)
    if review is None: raise HTTPException(404,'Review not found')
    return review


@app.post('/api/reviews/{review_id}/actions')
def review_action(review_id: str, payload: dict[str, Any]):
    from app.services.review_store import update_review
    reviewer=str(payload.get('reviewer','')).strip()
    action=str(payload.get('action','')).strip()
    claim_id=payload.get('claim_id')
    details=payload.get('details',{})
    if not reviewer: raise HTTPException(400,'reviewer is required')
    if not isinstance(details,dict): raise HTTPException(400,'details must be an object')
    try: review=update_review(review_id,reviewer,str(claim_id) if claim_id is not None else None,action,details)
    except ValueError as exc: raise HTTPException(400,str(exc))
    except KeyError as exc: raise HTTPException(404,str(exc))
    if review is None: raise HTTPException(404,'Review not found')
    return review


@app.post('/api/reports')
def generate_report(payload: dict[str, Any]):
    from app.services.report_builder import build_report, report_markdown
    from app.services.review_store import get_review
    claims=payload.get('claims',[])
    document=payload.get('document',{})
    if not isinstance(claims,list) or not isinstance(document,dict): raise HTTPException(400,'claims must be an array and document must be an object')
    review_id=payload.get('review_id')
    review=get_review(str(review_id)) if review_id else None
    if review and not claims:
        claims=review.get('payload',{}).get('claims',[])
    report=build_report(document,claims,review)
    report['markdown']=report_markdown(report)
    return report
