from __future__ import annotations
from typing import Any
from app.services.document_parser import split_references, detect_citations, detect_claims
from app.services.citation_matcher import match_citations_to_references
from app.services.claim_citation_mapper import map_claims_to_citations


VERDICTS = {'Supported','Partially supported','Unsupported','Contradicted','Outdated','Unverifiable'}


def build_analysis(page_data: list[dict[str, Any]], filename: str, document_id: str, file_type: str) -> dict[str, Any]:
    full_text='\n\n'.join(p.get('text','') for p in page_data if p.get('text'))
    body, ref_text, references = split_references(full_text)
    citations=detect_citations(body)
    claims=detect_claims(body)
    matches=match_citations_to_references(citations,references)
    mapped=map_claims_to_citations(claims,citations)
    # This endpoint intentionally does not infer support from metadata or keyword overlap.
    claim_results=[]
    for i, item in enumerate(mapped, 1):
        claim_text=item.get('claim') or item.get('text') or str(item)
        claim_results.append({
            'claim_id': item.get('claim_id') or f'claim-{i}',
            'claim': claim_text,
            'citations': item.get('citations', []),
            'citation_matches': [],
            'evidence': [],
            'verdict': 'Unverifiable',
            'verdict_reason': 'No source full text has been retrieved and evaluated. Citation metadata and relevance alone are not proof.',
            'human_verdict': None,
            'human_approved': False,
            'human_rejected': False,
            'review_comments': [],
        })
    # Link citation matches by citation identifier where possible; preserve all matches for traceability.
    for claim in claim_results:
        claim_cites=claim.get('citations') or []
        cite_texts={str(c.get('text','')) for c in claim_cites if isinstance(c,dict)}
        claim['citation_matches']=[m for m in matches if str(m.get('text','')) in cite_texts]
    return {
        'document': {'document_id':document_id,'filename':filename,'file_type':file_type,'page_count':len(page_data) if file_type=='pdf' else None,'text_characters':len(full_text),'reference_section_detected':bool(ref_text)},
        'pages':page_data,
        'claims':claim_results,
        'citations':citations,
        'citation_matches':matches,
        'references':references,
        'processing_notes':[
            'Claim and citation extraction are heuristic and may require reviewer correction.',
            'Claims are marked Unverifiable until claim-specific source evidence is assessed.',
            'Citation metadata matches do not establish that a citation supports a claim.',
            'Scanned documents require OCR; OCR is not currently enabled.',
        ]
    }
