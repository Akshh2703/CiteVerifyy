from __future__ import annotations
from typing import Any
from datetime import datetime, timezone

def build_report(document: dict[str,Any], claims: list[dict[str,Any]], review: dict[str,Any]|None=None) -> dict[str,Any]:
    counts={v:0 for v in ['Supported','Partially supported','Unsupported','Contradicted','Outdated','Unverifiable','Pending human review']}
    for c in claims:
        verdict=c.get('human_verdict') or c.get('verdict') or 'Pending human review'
        if verdict not in counts: verdict='Pending human review'
        counts[verdict]+=1
    approved=bool(review and review.get('payload',{}).get('human_report_approved'))
    return {'report_version':'1.0','generated_at':datetime.now(timezone.utc).isoformat(),'document':document,
            'summary':{'claim_count':len(claims),'verdict_counts':counts,'human_approved':approved,
                      'report_status':'human_verified' if approved else 'draft_pending_human_review'},
            'claims':claims,'review_events':review.get('events',[]) if review else [],
            'notice':'AI analysis is a research aid. The report is not human verified unless a reviewer explicitly approves it.'}

def report_markdown(report: dict[str,Any]) -> str:
    doc=report.get('document',{}); summary=report.get('summary',{}); lines=['# CiteVerify Evidence Report','',f"**Document:** {doc.get('filename','Unknown')}",f"**Document ID:** {doc.get('document_id','')}",f"**Status:** {summary.get('report_status','draft')}",f"**Claims analyzed:** {summary.get('claim_count',0)}",'','## Verdict summary','']
    for verdict,count in summary.get('verdict_counts',{}).items(): lines.append(f'- {verdict}: {count}')
    lines += ['', '## Claim review','']
    for i,c in enumerate(report.get('claims',[]),1):
        lines += [f'### Claim {i}',c.get('claim',c.get('text','')),f"- AI verdict: {c.get('verdict','Not assessed')}",f"- Human verdict: {c.get('human_verdict','Pending')}",f"- Evidence strength: {c.get('evidence_strength','Not assessed')}",f"- Reasoning: {c.get('reasoning','No reasoning supplied')}", '- Evidence:']
        evidence=c.get('evidence',[])
        if evidence:
            for e in evidence: lines.append(f"  - {e.get('passage','')} (page {e.get('page','unknown')})")
        else: lines.append('  - No evidence passages attached.')
        lines.append('')
    lines += ['', report.get('notice','')]
    return '\n'.join(lines)
