from __future__ import annotations
import re
from typing import Any
import requests

CROSSREF_URL='https://api.crossref.org/works'
OPENALEX_URL='https://api.openalex.org/works'
USER_AGENT='CiteVerify/0.1 (research citation verification prototype)'


def clean_doi(value: str) -> str | None:
    m=re.search(r'(10\.\d{4,9}/[^\s"<>]+)',value,re.I)
    return m.group(1).rstrip('.,;') if m else None


def _decode_abstract(index: dict[str,list[int]] | None) -> str | None:
    if not index: return None
    words=[]
    for word, positions in index.items():
        for pos in positions: words.append((pos,word))
    return ' '.join(word for _,word in sorted(words))

def _normalize_work(item: dict[str,Any], provider: str) -> dict[str,Any]:
    if provider=='crossref':
        authors=[]
        for a in item.get('author',[]):
            name=' '.join(x for x in [a.get('given'),a.get('family')] if x)
            if name: authors.append(name)
        title=(item.get('title') or [''])[0]
        date=item.get('published-print') or item.get('published-online') or item.get('created') or {}
        year=(date.get('date-parts') or [[None]])[0][0]
        return {'title':title,'authors':authors,'year':year,'doi':item.get('DOI'),
                'url':item.get('URL'),'container':(item.get('container-title') or [''])[0],
                'abstract':item.get('abstract'),'provider':'Crossref','open_access':None,'open_access_url':None,'pdf_url':None,'open_access_status':None}
    authors=[a.get('author',{}).get('display_name') for a in item.get('authorships',[]) if a.get('author')]
    oa=item.get('open_access',{}) or {}; best=item.get('best_oa_location') or {}
    return {'title':item.get('title'),'authors':authors,'year':item.get('publication_year'),'doi':item.get('doi'),'url':item.get('doi') or item.get('id'),'container':item.get('primary_location',{}).get('source',{}).get('display_name'),'abstract':_decode_abstract(item.get('abstract_inverted_index')),'provider':'OpenAlex','open_access':oa.get('is_oa'),'open_access_url':best.get('landing_page_url') or best.get('pdf_url'),'pdf_url':best.get('pdf_url'),'open_access_status':oa.get('oa_status')}


def search_research(query: str, limit: int=5, timeout: int=12) -> dict[str,Any]:
    q=query.strip()
    if not q: return {'query':q,'results':[],'errors':['Query is empty']}
    limit=max(1,min(int(limit),10)); results=[]; errors=[]
    doi=clean_doi(q)
    try:
        params={'query.bibliographic':doi or q,'rows':limit}
        if doi: params={'filter':'doi:'+doi,'rows':limit}
        r=requests.get(CROSSREF_URL,params=params,headers={'User-Agent':USER_AGENT},timeout=timeout)
        r.raise_for_status()
        for it in r.json().get('message',{}).get('items',[]): results.append(_normalize_work(it,'crossref'))
    except Exception as exc: errors.append(f'Crossref: {type(exc).__name__}')
    if len(results)<limit:
        try:
            r=requests.get(OPENALEX_URL,params={'search':doi or q,'per-page':limit},headers={'User-Agent':USER_AGENT},timeout=timeout)
            r.raise_for_status()
            for it in r.json().get('results',[]):
                normalized=_normalize_work(it,'openalex')
                if not any((normalized.get('doi') or '').lower()==(x.get('doi') or '').lower() for x in results): results.append(normalized)
        except Exception as exc: errors.append(f'OpenAlex: {type(exc).__name__}')
    return {'query':q,'results':results[:limit],'errors':errors,'retrieval_note':'Paper discovery results include metadata and legal Open Access links when indexed. Metadata/abstract matches are not full-text evidence verification.'}


def discover_open_access(doi_or_query: str, timeout: int=12) -> dict[str,Any]:
    """Find legitimate OA locations. This never attempts to bypass access controls."""
    doi=clean_doi(doi_or_query)
    q=doi or doi_or_query.strip()
    if not q: return {'query':q,'open_access_locations':[],'status':'not_found'}
    try:
        params={'filter':f'doi:{doi}','per-page':3} if doi else {'search':q,'per-page':3}
        response=requests.get(OPENALEX_URL,params=params,headers={'User-Agent':USER_AGENT},timeout=timeout)
        response.raise_for_status()
        items=response.json().get('results',[])
    except Exception as exc:
        return {'query':q,'open_access_locations':[],'status':'lookup_error','error':type(exc).__name__}
    if not items: return {'query':q,'open_access_locations':[],'status':'not_found'}
    work=items[0]; locations=[]
    for loc in work.get('locations',[]) or []:
        source=loc.get('source') or {}
        landing=loc.get('landing_page_url'); pdf=loc.get('pdf_url')
        if not landing and not pdf: continue
        locations.append({'landing_page_url':landing,'pdf_url':pdf,'repository_or_journal':source.get('display_name'),
                         'is_oa':loc.get('is_oa'),'license':loc.get('license')})
    locations=[x for x in locations if x.get('is_oa') or x.get('pdf_url')]
    return {'query':q,'title':work.get('title'),'doi':work.get('doi'),'open_access_locations':locations,
            'status':'open_access_found' if locations else 'no_open_access_location_found',
            'note':'Only public/open-access locations are returned. Restricted content is not bypassed.'}
