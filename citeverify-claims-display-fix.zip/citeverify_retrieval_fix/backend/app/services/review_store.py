from __future__ import annotations
import json, sqlite3, os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

DB_PATH = Path(os.getenv('CITEVERIFY_DB', Path(__file__).resolve().parents[2] / 'citeverify.sqlite3'))

def _connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con=sqlite3.connect(DB_PATH)
    con.execute('''CREATE TABLE IF NOT EXISTS review_sessions (
      review_id TEXT PRIMARY KEY, document_id TEXT NOT NULL, created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL, payload TEXT NOT NULL)''')
    con.execute('''CREATE TABLE IF NOT EXISTS review_events (
      event_id INTEGER PRIMARY KEY AUTOINCREMENT, review_id TEXT NOT NULL,
      timestamp TEXT NOT NULL, reviewer TEXT NOT NULL, action TEXT NOT NULL,
      claim_id TEXT, details TEXT NOT NULL)''')
    con.commit()
    return con

def now(): return datetime.now(timezone.utc).isoformat()

def create_review(review_id: str, document_id: str, payload: dict[str,Any]):
    timestamp=now()
    with _connect() as con:
        con.execute('INSERT INTO review_sessions VALUES (?,?,?,?,?)',(review_id,document_id,timestamp,timestamp,json.dumps(payload)))
        con.execute('INSERT INTO review_events(review_id,timestamp,reviewer,action,claim_id,details) VALUES (?,?,?,?,?,?)',(review_id,timestamp,'system','review_created',None,json.dumps({'document_id':document_id})))
    return {'review_id':review_id,'document_id':document_id,'created_at':timestamp,'updated_at':timestamp,'claims':payload.get('claims',[]),'status':'pending_review'}

def get_review(review_id: str):
    with _connect() as con:
        row=con.execute('SELECT review_id,document_id,created_at,updated_at,payload FROM review_sessions WHERE review_id=?',(review_id,)).fetchone()
        events=con.execute('SELECT timestamp,reviewer,action,claim_id,details FROM review_events WHERE review_id=? ORDER BY event_id',(review_id,)).fetchall()
    if not row: return None
    return {'review_id':row[0],'document_id':row[1],'created_at':row[2],'updated_at':row[3],'payload':json.loads(row[4]),'events':[{'timestamp':e[0],'reviewer':e[1],'action':e[2],'claim_id':e[3],'details':json.loads(e[4])} for e in events]}

def update_review(review_id: str, reviewer: str, claim_id: str|None, action: str, details: dict[str,Any]):
    allowed={'approve_claim','modify_verdict','reject_analysis','request_more_evidence','approve_report'}
    if action not in allowed: raise ValueError('Invalid review action')
    with _connect() as con:
        row=con.execute('SELECT payload FROM review_sessions WHERE review_id=?',(review_id,)).fetchone()
        if not row: return None
        payload=json.loads(row[0]); claims=payload.get('claims',[])
        if claim_id is not None:
            target=next((c for c in claims if str(c.get('claim_id'))==claim_id),None)
            if target is None: raise KeyError('claim_id not found')
            if action=='modify_verdict':
                verdict=details.get('verdict')
                if verdict not in {'Supported','Partially supported','Unsupported','Contradicted','Outdated','Unverifiable'}: raise ValueError('Invalid verdict')
                target['human_verdict']=verdict
            if action=='approve_claim': target['human_approved']=True
            if action=='reject_analysis': target['human_rejected']=True
            if action=='request_more_evidence': target['more_evidence_requested']=details.get('request','')
            target.setdefault('review_comments',[]).append(details.get('comment',''))
        if action=='approve_report':
            unreviewed=[c.get('claim_id','unknown') for c in claims if not (c.get('human_approved') or c.get('human_rejected') or c.get('human_verdict'))]
            if unreviewed: raise ValueError('All claims must be reviewed before approving the report')
            payload['human_report_approved']=True
        timestamp=now()
        con.execute('UPDATE review_sessions SET updated_at=?,payload=? WHERE review_id=?',(timestamp,json.dumps(payload),review_id))
        con.execute('INSERT INTO review_events(review_id,timestamp,reviewer,action,claim_id,details) VALUES (?,?,?,?,?,?)',(review_id,timestamp,reviewer,action,claim_id,json.dumps(details)))
        con.commit()
    return get_review(review_id)
