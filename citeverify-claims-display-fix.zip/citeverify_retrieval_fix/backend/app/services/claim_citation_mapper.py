from __future__ import annotations
from typing import Any



def map_claims_to_citations(claims: list[dict[str,Any]], citations: list[dict[str,Any]], max_distance: int=350) -> list[dict[str,Any]]:
    mapped=[]
    for claim in claims:
        start=claim.get('start'); end=claim.get('end')
        attached=[]
        if isinstance(start,int) and isinstance(end,int):
            for citation in citations:
                cstart=citation.get('start'); cend=citation.get('end')
                if not isinstance(cstart,int): continue
                # Citation inside the sentence is strongest; a nearby trailing citation is plausible but uncertain.
                if start<=cstart<=end:
                    attached.append({**citation,'mapping_basis':'same_sentence','mapping_confidence':'high'})
                elif end<=cstart<=end+max_distance:
                    attached.append({**citation,'mapping_basis':'adjacent_after_claim','mapping_confidence':'medium'})
        mapped.append({**claim,'citations':attached,'citation_status':'cited' if attached else 'no_detected_citation'})
    return mapped
