from __future__ import annotations
import re
from pathlib import Path
from typing import Any
import fitz
from docx import Document

SUPPORTED = {'.pdf', '.docx', '.txt'}

def extract_pdf(path: Path) -> list[dict[str, Any]]:
    pages=[]
    with fitz.open(path) as doc:
        for i,page in enumerate(doc,1):
            pages.append({'page':i,'text':page.get_text('text').strip()})
    return pages

def extract_docx(path: Path) -> list[dict[str, Any]]:
    doc=Document(path)
    chunks=[p.text.strip() for p in doc.paragraphs if p.text.strip()]
    # Also include table text, commonly used for research results.
    for table in doc.tables:
        for row in table.rows:
            cells=[c.text.strip() for c in row.cells]
            if any(cells): chunks.append(' | '.join(cells))
    return [{'page':None,'text':'\n'.join(chunks)}]

def extract_txt(path: Path) -> list[dict[str, Any]]:
    return [{'page':None,'text':path.read_text(encoding='utf-8',errors='replace')}]

def extract_document(path: Path, suffix: str) -> list[dict[str, Any]]:
    if suffix=='.pdf': return extract_pdf(path)
    if suffix=='.docx': return extract_docx(path)
    if suffix=='.txt': return extract_txt(path)
    raise ValueError('Unsupported format')

def split_references(text: str) -> tuple[str,str,list[str]]:
    heading=re.compile(r'(?im)^\s*(references|bibliography|works\s+cited|literature\s+cited|reference\s+list)\s*$')
    m=heading.search(text)
    if not m: return text,'',[]
    body=text[:m.start()].strip(); refs=text[m.end():].strip()
    lines=[x.strip() for x in refs.splitlines() if x.strip()]
    start=re.compile(r'^(?:\[\s*\d+\s*\]|\d+[.)]\s+|[A-Z][A-Za-z’\-]+,\s*(?:[A-Z].*|\d{4}))')
    entries=[]; cur=[]
    for line in lines:
        if cur and start.match(line): entries.append(' '.join(cur)); cur=[line]
        else: cur.append(line)
    if cur: entries.append(' '.join(cur))
    return body,refs,entries


def detect_citations(text: str) -> list[dict[str,Any]]:
    patterns=[
      ('numeric_bracket',r'\[(\d+(?:\s*[-,;]\s*\d+)*)\]'),
      ('author_year',r'\(([^()]{1,80}?(?:19|20)\d{2}[a-z]?[^()]*)\)'),
      ('doi',r'\b10\.\d{4,9}/[-._;()/:A-Z0-9]+\b'),
      ('url',r'https?://[^\s<>]+'),
      ('footnote_marker',r'(?<!\w)(?:\^\d{1,3}|\[\d{1,3}\])'),
    ]
    out=[]; seen=set()
    for kind,pat in patterns:
        for m in re.finditer(pat,text,re.I):
            val=m.group(0).rstrip('.,;')
            key=(kind,val,m.start())
            if key in seen: continue
            seen.add(key); out.append({'style_detected':kind,'text':val,'start':m.start(),'end':m.end()})
    return sorted(out,key=lambda x:x['start'])


def sentence_split(text: str) -> list[str]:
    # Protect common abbreviations and decimal numbers before sentence splitting.
    protected=text.replace('e.g.','e<dot>g<dot>').replace('i.e.','i<dot>e<dot>').replace('et al.','et al<dot>')
    chunks=re.split(r'(?<=[.!?])\s+(?=[A-Z0-9(])',protected)
    return [c.replace('<dot>','.').strip() for c in chunks if c.strip()]

def detect_claims(text: str, max_claims: int=300) -> list[dict[str,Any]]:
    # Baseline transparent heuristic: select declarative sentences, exclude headings,
    # very short text and reference-like lines. These are candidates, not verdicts.
    claims=[]; marker=re.compile(r'\b(is|are|was|were|has|have|shows?|demonstrates?|indicates?|suggests?|finds?|found|proves?|increases?|decreases?|improves?|reduces?|causes?|correlates?|associated|significant|result(?:s)?|study|studies|therefore|because)\b',re.I)
    # Split with offsets so downstream citation mapping can remain traceable.
    sentence_pattern=re.compile(r'(?<=[.!?])\s+(?=[A-Z0-9(])')
    protected=text.replace('e.g.','e<dot>g<dot>').replace('i.e.','i<dot>e<dot>').replace('et al.','et al<dot>')
    cursor=0
    for chunk in sentence_pattern.split(protected):
        start=cursor; end=start+len(chunk); cursor=end
        # Account for separator whitespace between sentence chunks.
        while cursor<len(protected) and protected[cursor].isspace(): cursor+=1
        s=chunk.replace('<dot>','.'); s=re.sub(r'\s+',' ',s).strip()
        if not 45<=len(s)<=1200 or not marker.search(s): continue
        if re.match(r'^(references|bibliography|works cited)\b',s,re.I): continue
        if re.match(r'^(figure|table)\s*\d+',s,re.I): continue
        claims.append({'text':s,'start':start,'end':end,'extraction_method':'heuristic','review_required':True,'candidate_type':'statement'})
        if len(claims)>=max_claims: break
    return claims
