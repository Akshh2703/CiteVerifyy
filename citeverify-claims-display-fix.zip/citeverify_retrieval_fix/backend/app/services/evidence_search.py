from __future__ import annotations
import re
from collections import Counter
from typing import Any

STOP = set('a an the and or but if to of in on at by for from with without into over under is are was were be been being this that these those it its their his her they them we our you your as than then not no yes can could may might must will would should do does did have has had'.split())

def _tokens(text: str) -> list[str]:
    return [t for t in re.findall(r"[a-z0-9][a-z0-9-]{1,}", text.lower()) if t not in STOP]

def _sentences(text: str) -> list[str]:
    return [s.strip() for s in re.split(r'(?<=[.!?])\s+', text) if len(s.strip()) > 35]

def search_evidence(claim: str, pages: list[dict[str, Any]], limit: int = 5) -> dict[str, Any]:
    """Find relevant passages in supplied text only; scores are relevance heuristics, not support verdicts."""
    claim_tokens = _tokens(claim)
    if not claim.strip() or not claim_tokens:
        return {'query': claim, 'passages': [], 'note': 'Enter a non-empty claim with searchable terms.'}
    claim_counts = Counter(claim_tokens)
    candidates=[]
    for page in pages:
        text=str(page.get('text',''))
        for sentence in _sentences(text):
            sent_counts=Counter(_tokens(sentence))
            shared=sum(min(claim_counts[t], sent_counts[t]) for t in claim_counts)
            coverage=shared/max(1,len(claim_counts))
            precision=shared/max(1,sum(sent_counts.values()))
            # Simple overlap score with modest precision weighting. Not an entailment model.
            score=round(100*(0.75*coverage+0.25*precision),1)
            if shared:
                candidates.append({'page':page.get('page'),'passage':sentence,'overlap_terms':sorted(t for t in claim_counts if t in sent_counts),'relevance_score':score,'score_type':'lexical_overlap'})
    candidates.sort(key=lambda x:(x['relevance_score'],len(x['overlap_terms'])),reverse=True)
    # Deduplicate repeated snippets
    seen=set(); passages=[]
    for c in candidates:
        key=re.sub(r'\W+',' ',c['passage'].lower())
        if key in seen: continue
        seen.add(key); passages.append(c)
        if len(passages)>=max(1,min(limit,20)): break
    return {'query':claim,'passages':passages,'note':'Passages are retrieved from the supplied document only. Lexical relevance is not proof that a passage supports or contradicts the claim.'}
