# CiteVerify API

Python 3.10+ backend for document parsing and citation research workflows.

## Setup

```bash
cd backend
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

Open `http://localhost:8000/docs` for API documentation.

## Endpoints
- `GET /api/health` — service health.
- `POST /api/analyze-document` — upload PDF, DOCX, or TXT; returns extracted pages, claim candidates, citations, reference entries, citation matches, and claim/citation mapping.
- `POST /api/analysis-pipeline` — integrated parse and conservative triage result in one upload call. Claim verdicts remain **Unverifiable** until source evidence is assessed.
- `POST /api/research-search` — scholarly metadata discovery via Crossref/OpenAlex.
- `POST /api/open-access-discovery` — discovery of public/open-access locations; does not bypass restricted access.
- `POST /api/match-citations` — citation/reference matching.
- `POST /api/map-claims-citations` — heuristic claim/citation mapping.
- `POST /api/evidence-search` — lexical passage retrieval over text supplied by the caller. Relevance is not proof.
- `POST /api/reviews` — create a persistent SQLite human-review session.
- `GET /api/reviews/{review_id}` — read a review and audit events.
- `POST /api/reviews/{review_id}/actions` — reviewer actions (approve, modify verdict, reject analysis, request evidence, approve report).
- `POST /api/reports` — create JSON + Markdown draft report from supplied document/claims and optional review session.

## Current limitations (honest)
- Claim detection and citation parsing are heuristic; expect missed/false detections and human correction.
- Metadata search is not full-text retrieval and is not evidence of claim support.
- The integrated pipeline currently conservatively labels claims `Unverifiable`; automated entailment/verdicts against source full text are not implemented.
- OA discovery relies on public metadata and returned locations; no paywall/DRM bypass.
- Scanned PDFs need OCR (not enabled).
- DOCX/TXT pagination is not inferred.
- API endpoints exist for review/report workflows, but frontend integration is pending.

## Hosted pretrained LLM for Ask CiteVerify (Groq)
Set the API key in the backend environment (never in frontend code). Obtain a key from the Groq developer console.

Windows PowerShell:
```powershell
$env:GROQ_API_KEY='YOUR_GROQ_API_KEY'
$env:GROQ_MODEL='llama-3.3-70b-versatile'
uvicorn app.main:app --reload --port 8000
```
Linux/macOS:
```bash
export GROQ_API_KEY='YOUR_GROQ_API_KEY'
export GROQ_MODEL='llama-3.3-70b-versatile'
uvicorn app.main:app --reload --port 8000
```
Ask CiteVerify uses a hosted pretrained model, grounded in the extracted document and analysis. It does not independently verify cited-paper full text.
