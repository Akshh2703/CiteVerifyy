# CiteVerify connected prototype

## Run frontend
```bash
npm install
npm run dev
```

## Run backend (separate terminal)
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

Frontend uploads the selected PDF/DOCX/TXT to `POST http://localhost:8000/api/analysis-pipeline`.
The analysis screen displays extracted claim candidates, citations, and references. The current backend is extraction/triage only; it does **not** retrieve source full text or verify claim support. The Ask CiteVerify panel answers limited questions about the extracted document data and explicitly avoids pretending to verify sources.

