@echo off
cd /d "%~dp0backend"
if not exist venv (
  echo Creating Python environment...
  python -m venv venv
)
call venv\Scripts\activate
if not exist venv\installed.flag (
  echo Installing backend dependencies...
  python -m pip install -r requirements.txt
  if errorlevel 1 pause & exit /b 1
  echo installed>venv\installed.flag
)
if "%GROQ_API_KEY%"=="" (
  echo NOTE: GROQ_API_KEY is not set. Upload analysis can work, but AI chat will return a setup message.
)
python -m uvicorn app.main:app --reload --port 8000
pause
